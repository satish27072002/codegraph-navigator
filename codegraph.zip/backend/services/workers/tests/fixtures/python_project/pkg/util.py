def helper(value: str) -> str:
    return value.strip()
