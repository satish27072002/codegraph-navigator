# Shared Contracts

This directory is reserved for schemas and shared service contracts.
