"""Shared contracts package."""
